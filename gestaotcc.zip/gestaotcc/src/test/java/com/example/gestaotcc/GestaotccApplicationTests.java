package com.example.gestaotcc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestaotccApplicationTests {

	@Test
	void contextLoads() {
	}

}
